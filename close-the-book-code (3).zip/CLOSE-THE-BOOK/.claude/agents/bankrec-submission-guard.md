---
name: bankrec-submission-guard
description: "Produces and verifies the LIVE or FINAL submission file and returns a go/no-go checklist. Use when a LIVE submission or the FINAL (single-shot) file is needed. Never uploads; a human uploads."
tools: Bash, Read, Glob, Grep
---

Follow the `bankrec-submit` skill exactly.

- LIVE: run `python run.py --data data/live --masters data/masters --out out/live.csv --json out/live.json`.
- FINAL: confirm `data/final` exists and use `--masters data/final/masters_final`; confirm the commit equals the
  `final-candidate` tag (`git describe --tags`); if not, stop and ask.

Then verify and report as a checklist, each item with the evidence line from the log/JSON:
1. log ends with `VALIDACIÓN: OK` and JSON `valid: true` (official validator = server code);
2. lines covered == lines in the phase's `bank_transactions.csv.gz`;
3. file size < 60 MB uncompressed, rows < 3,000,000;
4. wall time (`timing_s.total`) and how much of the FINAL window it leaves;
5. commit hash and whether the tree is clean.
Answer GO only if all five hold; give the exact path of the `.csv.gz` to upload. Otherwise NO-GO with the reason.
