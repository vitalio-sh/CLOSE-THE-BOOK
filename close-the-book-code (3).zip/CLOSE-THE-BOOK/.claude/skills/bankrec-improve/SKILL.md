---
name: bankrec-improve
description: "The loop for improving the bankrec reconciliation score safely: find the biggest loss, form one hypothesis, implement it as a rule change, validate on TRAIN with the gate, keep or revert, log it. Use when asked to improve the score, fix a segment, or add a rule."
---

# Improving the score, one change at a time

## 1. Find where the points are

```bash
python tools/analyze.py oracle out/eval/<baseline-tag> --window train_2506   # points per segment (ceiling)
python tools/analyze.py errors out/eval/<baseline-tag> --window train_2506   # missed pairs, wrong rows, examples
```

Pick the segment with the largest **points × feasibility**. Allocation F1 is pair-weighted: one remittance line can
settle 500 invoices, so documents (advices, batches) beat many small lines.

## 2. One hypothesis, one change

Write it down: "Lines of segment S fail because X (example ids); rule R will do Y; expected effect: +recall on S,
precision of R stays ≥ 0.9". Look at 5+ real examples in `<window>_errors.md` before coding.

## 3. Where code goes

- `recon/evidence.py`: parsing + linking of documents (advices, DD batches, cards, cheques, payment runs, confirming).
- `recon/rules/*.py`: one rule per file, `rule(t, ctx) -> list[Row] | None`; order in `recon/rules/__init__.py`.
  First rule that returns rows wins, and the ledger is updated (`ctx.apply`).
- `recon/settle.py`: amounts and exceptions for a chosen set of items (POLICIES §2–3).
- `recon/config.py`: every threshold, with the reason it has that value.
- Keep rules **precise**: when unsure, return `None` (the line becomes UNIDENTIFIED / a category; POLICIES says do
  not force matches).

## 4. Validate

`python tools/eval.py --tag <short-name>` then `python tools/gate.py out/eval/<short-name>`.
- PASS → commit with the TRAIN numbers in the message, `--accept` the baseline, commit `eval/baseline.json`, add a
  row to the progress table in README.md.
- FAIL → read the per-rule / per-segment deltas, adjust once; if it still fails, revert (`git checkout -- recon`)
  and write the finding in the "Lessons" list of the bankrec-knowledge skill.

## 5. Never

- decide on the sample alone; tune thresholds on the same month you report (use both TRAIN windows);
- add search without a cap (subset-sum over 40 items finds *some* exact sum for almost any amount: that was a
  0.36-precision rule);
- edit modules while a long run is in progress (they are imported lazily mid-run).
