---
name: bankrec-eval
description: "Measure the bank-reconciliation engine with the official scorer and decide whether a change is an improvement. Use before keeping any change to recon/ or run.py, when someone asks \"did it improve?\", \"what's our score?\", or before a LIVE/FINAL submission."
---

# Measuring the engine (bankrec)

The only trustworthy number is the **mean official score over the TRAIN windows**. The sample month is for fast
iteration only. Twice today a change gained +3.7 on the sample and *lost* on TRAIN (700k open items make
accidental matches common).

## Commands (run from the repo root)

```bash
python tools/eval.py --tag <name> --quick          # sample only, ~1 min — iterate, never decide
python tools/eval.py --tag <name>                  # sample + TRAIN 2025-06 + TRAIN 2025-03, ~15 min (2 in parallel)
python tools/gate.py out/eval/<name>               # PASS/FAIL vs eval/baseline.json, with deltas
python tools/gate.py out/eval/<name> --accept      # only after PASS: becomes the new baseline (commit eval/baseline.json)
```

Data layout expected: `data/{masters,sample,train,live}` (symlinks to the extracted zips). TRAIN windows rebuild the
open items at the window start from the golden, so they mimic LIVE.

## Gate rules (tools/gate.py)

- every window's file passes the **official validator** (recon/bankrec_score.py = server code);
- mean TRAIN score does not drop by more than 0.05; no TRAIN window drops by more than 0.30;
- total TRAIN runtime ≤ 1.3× baseline (FINAL must run inside the last hour).

## Reading the output

- `allocP / allocR`: precision/recall of (line, item) pairs, 50 % of the score. Recall is where most points are.
- `txnAcc`: whole line exactly right, 30 %. `excF1`: macro-F1 over 10 exception classes, 20 %, so **each class
  is worth ~2 points**. Rare classes (withholding, overpayment, bank charges) are cheap points.
- "precisión por regla": a rule below ~0.85 precision is usually net-negative; find out which segment it hurts with
  `python tools/analyze.py errors out/eval/<name> --window train_2506`.
- Runs are deterministic (run.py pins PYTHONHASHSEED=0): two runs of the same code give byte-identical files, so any
  delta is real.

## Rules of thumb

- Never report a sample-only improvement as an improvement.
- If a change raises recall but precision falls more than ~0.02 on TRAIN, it is probably net-negative: check the score.
- Check timing (`timing_s` in each window JSON): LIVE ≈ 6× a TRAIN month in lines.
