---
name: bankrec-knowledge
description: "Facts about the Grupo Valtermia bank-reconciliation data, policies and scoring learned while building the engine, plus lessons from failed experiments. Use whenever working on recon/ rules, analysing errors, or explaining how the data links together."
---

# What we know (verified on the data)

## Scoring
Score = 100 × (0.5 allocation-F1 over (line, item) pairs + 0.3 line accuracy + 0.2 macro-F1 of the 10 exception
classes). Amount tolerance max(0.01, 0.5 %). Pair-weighted: a few big lines dominate.

## How documents link to bank lines (recon/evidence.py)
| Document | Key in bank text | Notes |
|---|---|---|
| Remittance advice (pdf/csv/xlsx/txt) | payment ref (`REM/2025/0478`, `9053060237`, `AVISO …`) or entity+exact amount | arrives up to ~7 days AFTER the cash; per-line gross / deduction / reason / paid; deduction with reason → SHORT_DISPUTE (amount = paid) |
| SEPA DD batch | batch id (11 digits, in `REM…`) | bank amount = batch total; fee lines quote the same id (must not link) |
| Card settlement | settlement id prefix or account+net total+date | items settled at GROSS |
| Cheque deposit | deposit id `RCH…` | stub reference may be incomplete → name + amount |
| Payment run (transfers) | end_to_end_id (truncated to 16 chars in N43) | FX runs: compare with `orig_amount` |
| Confirming | run id `CF…` | ONE run is debited in several lines over weeks; each = N whole transfers ("N PROVEEDORES") |
| Returns | mandate `VTM-XX-nnnnnnn`, cheque no., card ****nnnn | amount = what is re-opened, exception RETURNED |

## Policies that matter most
- Discount only with the invoice's payment terms and booking date ≤ issue + discount days + 3.
- Withholding only customers in MX/BR/MA (1.25 / 1.5 / 10 %), sometimes on the TOTAL of several invoices → all rows.
- FX: bank rate is always WORSE than the ECB rate by 0.1–1.5 %; every invoice row (not credit notes) gets FX_DIFFERENCE.
- PDF clauses (instalments, retention, advance, "anula y sustituye") → recon/pdfclauses.py.
- The same printed number exists in several group companies → pick one (entity of the account, then payer).

## Lessons (experiments that failed — don't repeat)
- Sample-only gains: +3.7 on sample, −1 on TRAIN (completion without anchors, precision 0.36).
- FX match without the original amount: any big customer has *some* foreign invoice inside a 1.6 % window (0.28 precision).
- Overpayment without reference: 0.05 precision.
- Generic reference regex without the list of real prefixes picked `FRA 05…`, `VTO 04…` as invoices.
- Python `set` iteration over strings made runs nondeterministic → fixed with PYTHONHASHSEED=0 + dict.fromkeys.
- Committing with `git add -A` once pulled 600 MB of models/cache: `models/` is git-ignored now.
