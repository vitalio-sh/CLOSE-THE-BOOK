---
name: bankrec-submit
description: "Produce and verify a LIVE or FINAL submission file for the bankrec hackathon (one FINAL shot). Use when asked to submit, prepare the LIVE/FINAL file, or do the FINAL dress rehearsal."
---

# Submission protocol

## LIVE (leaderboard, many submissions)

```bash
python run.py --data data/live --masters data/masters --out out/live.csv --json out/live.json
```
Upload `out/live.csv.gz` only if the log ends with `VALIDACIÓN: OK`. (On failure run.py renames the files to
`*.INVALID.csv*` so they can't be uploaded by mistake.) Record the leaderboard score next to the git commit in
README.md: LIVE is the only measure that includes the Oct-2025 N43→camt change and the Sep-2025 advice layout.

## FINAL (ONE scored submission; a file rejected by validation does not count)

Before 17:00 (code freeze):
1. Full LIVE dress rehearsal with the frozen commit; note wall time from `out/live.json` → `timing_s.total`.
   It must leave ≥ 20 min of margin inside the FINAL window.
2. `git tag final-candidate` on that commit.

When FINAL data arrives (`final/` + `final/masters_final/`):
1. Extract next to the others; `ln -s ../../docs/final data/final`.
2. **Use `--masters data/final/masters_final`** (new subsidiary ZA01, ZAR, renamed entities).
3. `python run.py --data data/final --masters data/final/masters_final --out out/final.csv --json out/final.json`
4. Checks, all required: log says `VALIDACIÓN: OK`; `out/final.json` has `valid: true`; lines covered = lines in
   `final/bank_transactions.csv.gz`; file < 60 MB uncompressed and < 3 M rows; same commit as the best LIVE run.
5. Hand `out/final.csv.gz` to a human to upload. Never upload twice; ties go to the earlier submission.
